import { Component } from '@angular/core';

@Component({
  selector: 'app-admincompo',
  templateUrl: './admincompo.component.html',
  styleUrls: ['./admincompo.component.css']
})
export class AdmincompoComponent {

}
