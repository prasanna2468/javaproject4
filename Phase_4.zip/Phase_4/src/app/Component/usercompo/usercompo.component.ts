import { Component } from '@angular/core';

@Component({
  selector: 'app-usercompo',
  templateUrl: './usercompo.component.html',
  styleUrls: ['./usercompo.component.css']
})
export class UsercompoComponent {

}
